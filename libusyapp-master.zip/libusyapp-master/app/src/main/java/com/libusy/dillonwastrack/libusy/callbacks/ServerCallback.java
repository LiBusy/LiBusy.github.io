package com.libusy.dillonwastrack.libusy.callbacks;

public interface ServerCallback{
    void onSuccess(String result);
}
