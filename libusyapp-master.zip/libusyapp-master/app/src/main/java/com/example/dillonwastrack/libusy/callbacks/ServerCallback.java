package com.example.dillonwastrack.libusy.callbacks;

public interface ServerCallback{
    void onSuccess(String result);
}
